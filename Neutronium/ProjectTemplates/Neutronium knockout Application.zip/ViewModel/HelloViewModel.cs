﻿namespace Neutronium_knockout_Application1.ViewModel
{
    public class HelloViewModel
    {
        public string Message => "Hello Neutronium";
    }
}
