﻿namespace $safeprojectname$.ViewModel {
    public class HelloViewModel {
        public string Message => "Hello Neutronium";
    }
}
