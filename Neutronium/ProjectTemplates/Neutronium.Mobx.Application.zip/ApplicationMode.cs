﻿namespace $safeprojectname$
{
    public enum ApplicationMode {
        Production,
        Test,
        Dev
    }
}
