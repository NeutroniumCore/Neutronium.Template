exports.filePath = "./dist/hash.json";
exports.fileName = "hash.json";