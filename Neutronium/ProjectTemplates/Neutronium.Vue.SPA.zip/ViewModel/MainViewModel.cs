﻿namespace $safeprojectname$.ViewModel 
{
    public class MainViewModel : Vm.Tools.ViewModel
    {
        public MainViewModel()
        {
        }
    }
}
