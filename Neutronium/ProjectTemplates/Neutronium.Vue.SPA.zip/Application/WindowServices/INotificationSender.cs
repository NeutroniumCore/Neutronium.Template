﻿namespace $safeprojectname$.Application.WindowServices
{
    public interface INotificationSender
    {
        void Send(Notification notification);
    }
}
