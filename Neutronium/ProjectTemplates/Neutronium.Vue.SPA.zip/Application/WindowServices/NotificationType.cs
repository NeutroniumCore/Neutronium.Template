﻿namespace $safeprojectname$.Application.WindowServices
{
    public enum NotificationType
    {
        Error,
        Warning,
        Success,
        Info
    }
}
