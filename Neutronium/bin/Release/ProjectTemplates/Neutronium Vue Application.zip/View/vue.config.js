module.exports = {
  baseUrl: "./",
  filenameHashing: false
};
