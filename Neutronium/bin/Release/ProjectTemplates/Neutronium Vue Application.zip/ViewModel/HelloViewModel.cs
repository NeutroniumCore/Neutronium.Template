﻿namespace Neutronium_Simple_Application.ViewModel {
    public class HelloViewModel {
        public string Message => "Hello Neutronium";
    }
}
