exports.filePath = "./dist/hash.json";
exports.fileName = "hash.json";
exports.messagePath = "src/message.json";
exports.supportedLanguages = [
  "en-US"
]