module.exports = {
  publicPath: "./",
  filenameHashing: false
};
