﻿namespace $safeprojectname$.ViewModel.Pages 
{
    public class MainViewModel : Vm.Tools.ViewModel
    {
        public MainViewModel()
        {
        }
    }
}
