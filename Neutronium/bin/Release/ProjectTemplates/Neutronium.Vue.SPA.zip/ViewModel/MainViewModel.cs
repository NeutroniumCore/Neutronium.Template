﻿namespace $safeprojectname$.ViewModel 
{
    /// <summary>
    /// ViewModel for the "main" route
    /// </summary>
    public class MainViewModel : Neutronium.BuildingBlocks.ViewModel
    {
        public MainViewModel()
        {
        }
    }
}
