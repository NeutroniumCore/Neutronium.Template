﻿namespace $safeprojectname$.ViewModel 
{
    public class MainViewModel : BuildingBlocks.ViewModel
    {
        public MainViewModel()
        {
        }
    }
}
