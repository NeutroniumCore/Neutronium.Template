/*eslint no-unused-vars: ["error", { "args": "none" }]*/
function install(Vue) {
  //Call vue use here if needed
}

/*eslint no-unused-vars: ["error", { "args": "none" }]*/
function vueInstanceOption(vm) {
  //Return vue global option here, such as vue-router, vue-i18n, mix-ins, ....
  return {};
}

export { install, vueInstanceOption };
