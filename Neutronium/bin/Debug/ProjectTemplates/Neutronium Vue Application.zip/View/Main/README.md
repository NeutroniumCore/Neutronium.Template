# main

> A Vue.js neutronium project

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:9000
npm run dev

# build for neutronium with map source file and minification
npm run build
```