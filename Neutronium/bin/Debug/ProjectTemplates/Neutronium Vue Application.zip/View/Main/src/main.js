import Vue from 'vue'
import App from './App.vue'
import data from '../data/data'

new Vue({
	components:{
		App
	},
  el: '#main',
  data
})
